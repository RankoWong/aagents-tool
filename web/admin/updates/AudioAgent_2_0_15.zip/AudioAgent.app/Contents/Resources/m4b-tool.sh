#!/bin/bash
# m4b-tool 启动脚本

# 设置 PATH，确保能找到 ffmpeg
export PATH="/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/usr/bin:/bin"

# PHP 8.2 路径
PHP="/opt/homebrew/Cellar/php@8.2/8.2.30/bin/php"
# 项目目录
PROJECT_DIR="/Users/wangdafeng/m4b-tool"

# 执行 m4b-tool（不使用 exec，以便输出重定向能正常工作）
"$PHP" "$PROJECT_DIR/bin/m4b-tool.php" "$@"
